from django.contrib.sitemaps import Sitemap
from Mainapp.models import Blog, Blog_Category, WebStory
from Mainapp.models import Service
from django.utils.text import slugify
from django.conf import settings
import os

class BlogDetailSitemap(Sitemap):
    changefreq = 'daily'
    priority = 0.9

    def items(self):
        return Blog.objects.filter(status=True)

    def location(self, obj):
        return f"/{slugify(obj.slug)}/"

class BlogCategorySitemap(Sitemap):
    changefreq = 'daily'
    priority = 0.7

    def items(self):
        return Blog_Category.objects.all()

    def location(self, obj):
        return f"/blogs/{slugify(obj.name)}/"

class WebStoryDetailSitemap(Sitemap):
    changefreq = 'daily'
    priority = 0.8

    def items(self):
        return WebStory.objects.all()

    def location(self, obj):
        return f"/story/{obj.pk}/"

class StaticViewSitemap(Sitemap):
    priority = 0.8
    changefreq = 'daily'

    def items(self):
        return [
            'Blog_Home', 'Contactus', 'About', 'Faq', 'interview', 
            'our_teem', 'services'
        ]

    def location(self, item):
        from django.urls import reverse
        return reverse(item)

class MediaSitemap(Sitemap):
    priority = 0.5
    changefreq = 'daily'

    def items(self):
        media_files = []
        media_root = settings.MEDIA_ROOT
        for root, dirs, files in os.walk(media_root):
            for file in files:
                relative_path = os.path.relpath(os.path.join(root, file), media_root)
                media_files.append(relative_path.replace("\\", "/"))
        return media_files

    def location(self, item):
        return f"{settings.MEDIA_URL}{item}"
    
class ServiceSitemap(Sitemap):
    changefreq = 'daily'
    priority = 0.8

    def items(self):
        return Service.objects.all() 

    def location(self, obj):
        return f"/service-details/{obj.slug}/"