from django.shortcuts import render, get_object_or_404, redirect
from Mainapp.models import *
import sys,json
from django.conf import settings
import urllib.request
from django.shortcuts import redirect
from django.contrib import messages
import itertools
from collections import Counter
from django.views.generic.base import TemplateView
import os
import json
import hashlib
import base64
from django.http import HttpResponse
from django.core.mail import send_mail
import urllib.parse
import urllib.request
import asyncio
from telegram import Bot
from threading import Thread
from django.http import JsonResponse
from django.urls import reverse
import requests
import threading

# Create your views here.

def search_results(request):
    query = request.GET.get('query', '')
    if query:
        blogs = Blog.objects.filter(title__icontains=query)
    else:
        blogs = Blog.objects.none()
    return render(request, 'search_result.html', {'blogs': blogs})

######################################################################

def Blog_Home(request):
    review = EmployeeReview.objects.all()
    clients = OurClient.objects.all()
    bcate = BlogCategory.objects.all()
    blog = Blog.objects.filter(status=True).exclude(blog_categories__name__iexact='Interview').exclude(blog_categories__name__iexact='News').order_by('-date')[:6]
    interview = Blog.objects.filter(status=True, blog_categories__name__iexact='Interview').order_by('-date')[:6]
    news = Blog.objects.filter(status=True, blog_categories__name__iexact='News').order_by('-date')[:6]
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    homedetail = Home_Page_Detail.objects.all()
    top_list_articles = TopListArticles.objects.filter(status=True).order_by('-date').first()

    recent_magazines = Blog.objects.filter(status=True, magazine_iframe__isnull=False, magazine_thumbnail__isnull=False, magazine_name__isnull=False
    ).exclude(
        magazine_iframe='',
    ).exclude(
        magazine_thumbnail='',
    ).exclude(
        magazine_name=''
    ).order_by('-date')[:10]

    recent_stories = WebStory.objects.all().order_by('-id').prefetch_related('slides')[:10]

    # Fetch all top featured services ordered by 'order'
    left_services = TopFeaturedService.objects.filter(position='left').order_by('order')
    right_services = TopFeaturedService.objects.filter(position='right').order_by('order')
    
    # Assuming only one main image
    section_image = ServiceSectionImage.objects.first()
    

    return render(request, "index.html",{'interview':interview, 'news':news,'review': review,'cate':bcate, "blogdeatils": blog, "social":social, "recent_magazines": recent_magazines,
                                         'clients': clients, "homedetail":homedetail,'seo_contents': seo_contents, 'Seo':Seo, 'recent_stories': recent_stories,'top_list_articles':top_list_articles,'left_services': left_services,
        'right_services': right_services,
        'section_image': section_image,})

############################################################################################################################################# 

def blogcatecount():
    cate = Blog.objects.values_list('blog_categories__name', flat=True)
    print('Categories', cate, type(cate))
    counts = Counter(cate)
    count_dict = dict(counts)
    for i in count_dict:
        print(i, count_dict[i])
        bcate = BlogCategory.objects.filter(blogcategory__icontains=i)
        if bcate.exists():
            bc = bcate[0]
            bc.blogcategory_count = count_dict[i]
            bc.save(update_fields=['blogcategory_count'])
            print("Function")
        else:
            bcate = BlogCategory(
                blogcategory=i, blogcategory_count=count_dict[i])
            bcate.save()
            print("execute")

#############################################################################################################################################


def Blogs(request, var=None):
    bcate = BlogCategory.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    blogcatecount()
    social = Social_Media_Links.objects.all()
    base_url = "{0}://{1}{2}".format(request.scheme, request.get_host(), request.path)

    # ✅ Filter by status=True and exclude 'interview' and 'news'
    latest_blogs = Blog.objects.filter(status=True) \
        .exclude(blog_categories__name__iexact='interview') \
        .exclude(blog_categories__name__iexact='news') \
        .order_by('-date')[:5][::-1]

    return render(request, "blog.html", {
        'cate': bcate,
        'link': base_url,
        'social': social,
        'seo_contents': seo_contents,
        'Seo': Seo,
        'latest_blogs': latest_blogs
    })


#############################################################################################################################################

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse  
from django.db.models.functions import ExtractYear
from django.template.loader import render_to_string

def Interview(request, var=None):
    bcate = BlogCategory.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()
    base_url = f"{request.scheme}://{request.get_host()}{request.path}"

    year = request.GET.get("year")
    page = request.GET.get("page", 1)

    blogs_qs = Blog.objects.filter(
        blog_categories__name__iexact="interview",
        status=True
    ).order_by("-date")

    years = blogs_qs.annotate(
        y=ExtractYear("date")
    ).values_list("y", flat=True).distinct().order_by("-y")

    selected_year = None
    if year and year.isdigit():
        selected_year = int(year)
        blogs_qs = blogs_qs.filter(date__year=selected_year)

    latest_interview = blogs_qs[:15]

    paginator = Paginator(blogs_qs, 20)
    try:
        latest_blogs = paginator.page(page)
    except (PageNotAnInteger, EmptyPage):
        latest_blogs = paginator.page(1)

    # ================= AJAX =================
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":

        # First load / Year filter / All interviews (replace list)
        if "page" not in request.GET:
            html = render_to_string(
                "interview_list.html",
                {"latest_blogs": latest_blogs},
                request=request
            )
            return JsonResponse({
                "html": html,
                "has_next": latest_blogs.has_next()
            })

        # Load more (append)
        return JsonResponse({
            "articles": [{
                "title": b.title,
                "slug": b.slug,
                "name": b.name,
                "date": b.date.strftime("%B %d, %Y") if b.date else "",
                "description": b.discription,
                "image_url": b.image.url if b.image else "https://via.placeholder.com/800x400",
            } for b in latest_blogs],
            "has_next": latest_blogs.has_next()
        })


    # ================= NORMAL =================
    return render(request, "interview.html", {
        "cate": bcate,
        "link": base_url,
        "social": social,
        "seo_contents": seo_contents,
        "Seo": Seo,
        "latest_blogs": latest_blogs,
        "latest_interview": latest_interview,
        "years": years,
        "selected_year": selected_year,
    })



#############################################################################################################################################

def Blogscate(request, cate, var=None):
    if cate.lower() == 'interview':
        return redirect(reverse('interview'))
    bcate = BlogCategory.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    blogcatecount()
    social = Social_Media_Links.objects.all()
    return render(request, "blogs.html", { 'cate':bcate, "social":social, 'seo_contents': seo_contents, 'Seo':Seo,'blcate':cate,})


#################################################################################telegram#######################

async def send_telegram_messages(token, chat_ids, name, message):
    bot = Bot(token=token)
    for chat_id in chat_ids:
        try:
            telegram_message = f"New comment on the blog:\n\nName: {name}\nMessage: {message}"
            await bot.send_message(chat_id=chat_id, text=telegram_message)
            print(f"Success sending Telegram message to chat_id {chat_id}")
        except Exception as e:
            print(f"Error sending Telegram message to chat_id {chat_id}: {e}")

##################################################################################################################

async def send_telegram_messages_contuctus(token, chat_ids, name, email, phone, subject, message):
    bot = Bot(token=token)
    telegram_message = (f"New contact request:\n\n" f"Name: {name}\n"f"Email: {email}\n"f"Phone: {phone}\n"f"Subject: {subject}\n"f"Message: {message}")

    for chat_id in chat_ids:
        try:
            await bot.send_message(chat_id=chat_id, text=telegram_message)
            print(f"Success sending Telegram message to chat_id {chat_id}")
        except Exception as e:
            print(f"Error sending Telegram message to chat_id {chat_id}: {e}")


################################################################################end #################################        

def Blog_Deatils(request, name):
    current_path = request.path
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    name = name.replace('-', ' ')
    base_url = "{0}://{1}{2}".format(request.scheme, request.get_host(), request.path)

    # ✅ Only get blog with status=True
    bldet = get_object_or_404(Blog, slug__iexact=name, status=True)
    bldet1 = bldet.slug
    cate = Blog.objects.get(slug=bldet1).blog_categories

    # ✅ Related blogs with status=True
    blog = Blog.objects.filter(blog_categories=cate, status=True).order_by('-date')
    blog1 = blog.order_by('-date').values()[0:5]

    # ✅ Blog details and comments
    blogdet = Blogdetails.objects.filter(blogid=bldet.blogid)
    bl = BlogComments.objects.filter(blog=bldet, isapproved=True)
    num = len(bl)

    # ✅ Social links and categories
    social = Social_Media_Links.objects.all()
    bcate = BlogCategory.objects.exclude(blogcategory__icontains="Interview")

    # ✅ Handle comment POST
    if request.method == 'POST':
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode())

        if result['success']:
            nam = request.POST.get("Name")
            mess = request.POST.get("Message")
            if nam and mess:
                bcom = BlogComments(blog=bldet, name=nam, Commenttext=mess)
                bcom.save()
                email_subject = "New Comment Submitted"
                email_message = f"Name: {nam}\nMessage: {mess}"
                email_from = settings.EMAIL_HOST_USER
                recipient_list = ['sales@allaroundworlds.com']
                Thread(target=send_mail, args=(email_subject, email_message, email_from, recipient_list)).start()
                messages.success(request, 'Your comment is successfully submitted and will show after approval.')

                chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]
                asyncio.run(send_telegram_messages('6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4', chat_ids, nam, mess))
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')

        return redirect(request.META['HTTP_REFERER'])

    return render(request, "blog-details.html", {
        'current_path': current_path,
        'det': bldet,
        "blogdeatils": blog,
        'comm': bl,
        'rc': blog1,
        'num': num,
        'cate': bcate,
        'link': base_url,
        'blogdet': blogdet,
        "social": social,
        'seo_contents': seo_contents,
        'Seo': Seo
    })

##############################################################################################################################################

def likes(request):
    if request.method == 'POST':
        post_id = request.POST.get('task')

        try:
            blog_post = Blog.objects.get(blogid=int(post_id))
            
            # Ensure likes is an integer
            if blog_post.likes is None:
                blog_post.likes = 0
            
            blog_post.likes += 1
            blog_post.save()
            return HttpResponse(status=200)

        except Blog.DoesNotExist:
            return HttpResponse(status=404)
        except ValueError:
            return HttpResponse(status=400)
        except Exception as e:
            print("Error:", str(e))
            return HttpResponse(status=500)

######################################################################################################################################
        
def Contactus(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()

    if request.method == "POST":
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode())

        if result['success']:
            Name = request.POST.get("Name")
            Email_id = request.POST.get("Email")
            Phone = request.POST.get("Phone")
            Subject = request.POST.get("Subject")
            Message = request.POST.get('Message')
            ct = Contact(Name=Name, Email=Email_id, Phone=Phone, Message=Message, Subject=Subject)
            ct.save()
            email_subject = f"New Contact from {Name}"
            email_message = f"Name: {Name}\nEmail: {Email_id}\nPhone: {Phone}\nSubject: {Subject}\nMessage: {Message}"
            email_from = settings.EMAIL_HOST_USER
            recipient_list = ['sales@allaroundworlds.com']
            Thread(target=send_mail, args= (email_subject, email_message, email_from, recipient_list)).start()
            messages.success(request, 'Your form has been submitted successfully.')
            chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]
            asyncio.run(send_telegram_messages_contuctus('6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4', chat_ids, Name, Email_id, Phone, Subject, Message))
        else:
            messages.warning(request, 'reCAPTCHA verification failed. Please try again.')
        return redirect(request.META['HTTP_REFERER'])

    return render(request, "contactus.html", {"social": social, 'seo_contents': seo_contents, 'Seo': Seo})

#############################################################################################################################################

def Terms_Of_Service(request, var=None):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    ter = TermsofServiceDetail.objects.all().order_by('id')
    social = Social_Media_Links.objects.all()
    # ban = PageBanner.objects.all()
    ter = list(ter)
    num = 0
    number = len(ter)
    if number % 2 == 0:
        num = int(number/2)
    else:
        num = int(number/2)
        num = num+1
    list1 = ter[:num]
    list2 = ter[num:]
    comb = list(itertools.zip_longest(list1, list2, fillvalue=None))
    return render(request, "terms-of-service.html", {'ter': comb, "social":social, 'seo_contents': seo_contents, 'Seo':Seo})

#############################################################################################################################################

def About(request, var=None):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    At = AboutDetail.objects.all().order_by('id')
    social = Social_Media_Links.objects.all()
    return render(request, "aboutus.html", {"About": At , "social":social, 'seo_contents': seo_contents, 'Seo':Seo})

#############################################################################################################################################

def Faq(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    Fq = FaqDetail.objects.all()
    social = Social_Media_Links.objects.all()
    return render(request, "faq.html", {'Faq': Fq, "social":social, 'seo_contents': seo_contents,'Seo':Seo})

############################################################################################################################################

def custom_404(request, exception):
    return redirect('/') 

#############################################################################################################################################

def acme_challenge(request, token):
    your_public_key_n_value = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAk8CXbWVkMbt8q/NHl7QkdhjAg03rrCd276BVtpWEY1JTZUyubC/QSZc0KM1phEhdd+w+oj4ptPYqOsCdCvU4YATU8iU1RsGHuw8EkpHt3g7qx3/8t4LFtFYNe0xam/7tRprT00BcrcuETlV0WNb78kGmSrrDhDBQ9kPfgsKg1YJU3N0KJAtaGmeUhEb05hjOoDKJg1fO9WbaJhhj60EbEgWic6y8OOa047y4lJyJZlsIGkn+62qg0TvXNHIdwM2Fej29Xcy+DWzLDVH1Bp+mSSeMJsG1kYiMjop9H5Qc28vY95slmlfFHZ+PU68KWF8MwAcbaG5DpDOz3Od5qECivQIDAQAB "
    # Use the actual token and JWK values
    jwk = {"e": "AQAB", "kty": "RSA", "n": your_public_key_n_value}
    serialized_jwk = json.dumps(jwk, sort_keys=True, separators=(',', ':'))
    sha256_digest = hashlib.sha256(serialized_jwk.encode('utf-8')).digest()
    thumbprint = base64.urlsafe_b64encode(sha256_digest).decode('utf-8').rstrip("=")
    key_authorization = token + '.' + thumbprint

    # File path for the token file
    file_path = os.path.join('Mainapp/static/.well-known/acme-challenge', token)

    # Write key_authorization to the file
    with open(file_path, 'w') as file:
        file.write(key_authorization)

    # Read the file and return its content in the response
    with open(file_path, 'r') as file:
        response_content = file.read()

    return HttpResponse(response_content, content_type='text/plain')

#############################################################################################################################################

# async def send_telegram_messages_interview(token, chat_ids, message):
#     bot = Bot(token=token)
#     for chat_id in chat_ids:
#         try:
#             # Send the message and capture the response
#             response = await bot.send_message(chat_id=chat_id, text=message, parse_mode='Markdown')
#             print(f"Telegram API Response: {response}")
#             print(f"Success sending Telegram message to chat_id {chat_id}")
#         except Exception as e:
#             print(f"Error sending Telegram message to chat_id {chat_id}: {e}")



########################################################################################################################################


# def submit_interview_response(request):
#     if request.method == 'POST':
#         # reCAPTCHA validation
#         recaptcha_response = request.POST.get('g-recaptcha-response')
#         url = 'https://www.google.com/recaptcha/api/siteverify'
#         values = {
#             'secret': settings.RECAPTCHA_PRIVATE_KEY,
#             'response': recaptcha_response
#         }
#         data = urllib.parse.urlencode(values).encode()
#         req = urllib.request.Request(url, data=data)
#         response = urllib.request.urlopen(req)
#         result = json.loads(response.read().decode())

#         if result['success']:
#             name = request.POST.get('name')
#             website_URL = request.POST.get('website_URL')
#             about_yourself = request.POST.get('about_yourself')
#             current_profession = request.POST.get('current_profession')
#             business_overview = request.POST.get('business_overview')
#             competitive_advantage = request.POST.get('competitive_advantage')
#             growth_plans = request.POST.get('growth_plans')
#             yearly_review = request.POST.get('yearly_review')
#             teamwork_unity = request.POST.get('teamwork_unity')
#             research_innovation = request.POST.get('research_innovation')
#             startup_tips = request.POST.get('startup_tips')
#             thoughts = request.POST.get('thoughts')
#             image1 = request.FILES.get('image1')
#             image2 = request.FILES.get('image2')
#             image3 = request.FILES.get('image3')

#             # Save interview response to the database
#             response = InterviewResponse(
#                 name=name,
#                 website_URL=website_URL,
#                 about_yourself=about_yourself,
#                 current_profession=current_profession,
#                 business_overview=business_overview,
#                 competitive_advantage=competitive_advantage,
#                 growth_plans=growth_plans,
#                 yearly_review=yearly_review,
#                 teamwork_unity=teamwork_unity,
#                 research_innovation=research_innovation,
#                 startup_tips=startup_tips,
#                 thoughts=thoughts,
#                 image1=image1,
#                 image2=image2,
#                 image3=image3
#             )
#             response.save()

#             # Send email notification
#             email_subject = f"{name} has submitted interview questions 🤓🤓🤓🤓"
#             email_message = (
#                 f"Name: {name}\n"
#                 f"Website URL: {website_URL}\n"
#                 "Message: 🎉 Great news, team! Someone has just submitted their interview for consideration on our website. "
#                 "Let's review their submission and get ready to showcase another inspiring story! 🌟"
#             )
#             email_from = settings.EMAIL_HOST_USER
#             recipient_list = ['sales@allaroundworlds.com']
#             Thread(target=send_mail, args=(email_subject, email_message, email_from, recipient_list)).start()

#             # Send Telegram notifications
#             chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]
#             asyncio.run(send_telegram_messages_interview('6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4', chat_ids, name))

#             # Notify the user and redirect to the thank-you page
#             messages.success(request, 'Your interview response has been successfully submitted!')
#             return redirect('thankyou') 

#         else:
#             messages.warning(request, 'reCAPTCHA verification failed. Please try again.')
#             return redirect(request.META['HTTP_REFERER'])

#     return render(request, 'questions.html')


def thankyou(request):
    return render(request, 'thankyou.html')

###########################################################################################################################################


# Synchronous function to send Telegram notification
def send_telegram_notification(message, bot_token, chat_id):
    try:
        send_text = f'https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={urllib.parse.quote(message)}&parse_mode=Markdown'
        response = requests.get(send_text)
        if response.status_code == 200:
            print(f"Message sent successfully to chat_id {chat_id}")
        else:
            print(f"Failed to send message to chat_id {chat_id}, status code: {response.status_code}")
    except Exception as e:
        print(f"Error sending message to chat_id {chat_id}: {e}")


def send_notifications_in_background(message, bot_token, chat_ids):
    for chat_id in chat_ids:
        thread = threading.Thread(target=send_telegram_notification, args=(message, bot_token, chat_id))
        thread.start()


####################################################################################################################################################


# Your form handling view
def submit_interview_response(request):
    if request.method == 'POST':
        # reCAPTCHA validation
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }

        response = requests.post(url, data=values)
        result = response.json()

        if result['success']:
            interview_type = request.POST.get('interview_type')

            if interview_type == 'Business Owners/Entrepreneurs':
                # Business Owners/Entrepreneurs specific fields
                name = request.POST.get('name_business_owner')
                website_url = request.POST.get('website_URL_business_owner')
                facebook_url = request.POST.get('facebook_URL_business_owner', '')
                linkedin_url = request.POST.get('linkedin_URL_business_owner', '')
                instagram_url = request.POST.get('instagram_URL_business_owner', '')
                twitter_url = request.POST.get('twitter_URL_business_owner', '')
                about_yourself = request.POST.get('about_yourself_business_owner')
                business_overview = request.POST.get('business_overview_business_owner')
                key_achievement = request.POST.get('key_achievement_business_owner')
                growth_plans = request.POST.get('growth_plans_business_owner')
                competitive_advantage = request.POST.get('competitive_advantage_business_owner')
                advice_entrepreneurs = request.POST.get('advice_entrepreneurs_business_owner')

                # Handle images (optional fields)
                image1 = request.FILES.get('image1_business_owner')
                image2 = request.FILES.get('image2_business_owner')
                image3 = request.FILES.get('image3_business_owner')

                # Save data to BusinessOwner model
                business_owner = BusinessOwner(
                    name=name,
                    website_url=website_url,
                    facebook_url=facebook_url,
                    linkedin_url=linkedin_url,
                    instagram_url=instagram_url,
                    twitter_url=twitter_url,
                    about_yourself=about_yourself,
                    business_overview=business_overview,
                    key_achievement=key_achievement,
                    growth_plans=growth_plans,
                    competitive_advantage=competitive_advantage,
                    advice_entrepreneurs=advice_entrepreneurs,
                    image1=image1,
                    image2=image2,
                    image3=image3
                )
                business_owner.save()

                # Prepare the message with emojis for Business Owners/Entrepreneurs
                message = f"""
📋 **New Business Owners/Entrepreneurs Interview Submission** 📋

👤 **Name**: {name}
🌐 **Website URL**: {website_url}
🔗 **Facebook**: {facebook_url if facebook_url else 'N/A'}
🔗 **LinkedIn**: {linkedin_url if linkedin_url else 'N/A'}
🔗 **Instagram**: {instagram_url if instagram_url else 'N/A'}
🔗 **Twitter (X)**: {twitter_url if twitter_url else 'N/A'}

📝 **About**: {about_yourself}
🏢 **Business Overview**: {business_overview}
                """

            elif interview_type == 'Industry Leaders/Professionals':
                # Professionals specific fields
                name = request.POST.get('name_professional')
                website_url = request.POST.get('website_URL_professional')
                facebook_url = request.POST.get('facebook_URL_professional', '')
                linkedin_url = request.POST.get('linkedin_URL_professional', '')
                instagram_url = request.POST.get('instagram_URL_professional', '')
                twitter_url = request.POST.get('twitter_URL_professional', '')
                about_yourself = request.POST.get('about_yourself_professional')
                current_role = request.POST.get('current_role_professional')
                professional_accomplishment = request.POST.get('professional_accomplishment_professional')
                career_challenge = request.POST.get('career_challenge_professional')
                stay_ahead = request.POST.get('stay_ahead_professional')
                advice_young_professional = request.POST.get('advice_young_professional')

                # Handle images (optional fields)
                image1 = request.FILES.get('image1_professional')
                image2 = request.FILES.get('image2_professional')
                image3 = request.FILES.get('image3_professional')

                # Save data to Professional model
                professional = Professional(
                    name=name,
                    website_url=website_url,
                    facebook_url=facebook_url,
                    linkedin_url=linkedin_url,
                    instagram_url=instagram_url,
                    twitter_url=twitter_url,
                    about_yourself=about_yourself,
                    current_role=current_role,
                    professional_accomplishment=professional_accomplishment,
                    career_challenge=career_challenge,
                    stay_ahead=stay_ahead,
                    advice_young_professional=advice_young_professional,
                    image1=image1,
                    image2=image2,
                    image3=image3
                )
                professional.save()

                # Prepare the message with emojis for Industry Leaders/Professionals
                message = f"""
📋 **New Industry Leaders/Professionals Interview Submission** 📋

👤 **Name**: {name}
🌐 **Website URL**: {website_url}
🔗 **Facebook**: {facebook_url if facebook_url else 'N/A'}
🔗 **LinkedIn**: {linkedin_url if linkedin_url else 'N/A'}
🔗 **Instagram**: {instagram_url if instagram_url else 'N/A'}
🔗 **Twitter (X)**: {twitter_url if twitter_url else 'N/A'}

📝 **About**: {about_yourself}
🏢 **Current Role**: {current_role}
                """

            # Send Telegram notifications
            bot_token = '6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4'
            chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]
            for chat_id in chat_ids:
                send_telegram_notification(message, bot_token, chat_id)

            messages.success(request, 'Your interview response has been successfully submitted!')

            return redirect('thankyou')
        else:
            # reCAPTCHA failed
            messages.error(request, 'reCAPTCHA verification failed. Please try again.')
            return redirect(request.META['HTTP_REFERER'])

    return render(request, 'questions.html')

######################################################################################################################################


def blog_data_json(request):
    start = int(request.GET.get('start', 0))
    limit = int(request.GET.get('limit', 9))
    end = start + limit
    base_query = Blog.objects.filter(status=True)

    if "category" in request.GET:
        category = request.GET.get('category')
        category = category.replace('-', ' ')
        blogs = base_query.filter(blog_categories__name__iexact=category).order_by('-date').values(
            'title', 'short_discription', 'image', 'slug', 'name', 'date', 'blog_categories__name')[start:end]
    else:
        blogs = base_query.exclude(blog_categories__name__iexact='interview') \
                        .exclude(blog_categories__name__iexact='news') \
                        .order_by('-date').values(
            'title', 'short_discription', 'image', 'slug', 'date', 'name', 'blog_categories__name')[start:end]


    blogs_list = list(blogs)
    return JsonResponse(blogs_list, safe=False)

###################################################--web stories--################################################################################

from django.template.loader import render_to_string
from django.core.paginator import Paginator

def web_story_list(request):
    stories_list = WebStory.objects.prefetch_related('slides').all().order_by('-id')
    paginator = Paginator(stories_list, 8)  

    page_number = request.GET.get('page', 1)
    stories = paginator.get_page(page_number)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        stories_html = render_to_string('stories_list.html', {'stories': stories})
        return JsonResponse({
            'stories_html': stories_html,
            'has_next': stories.has_next(), 
        })

    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()

    return render(request, "web_story_list.html", {
        'stories': stories, 
        "social": social,
        'seo_contents': seo_contents,
        'Seo': Seo
    })

#################################################---web-story-details--###############################################################

def web_story_detail(request, slug):
    story = get_object_or_404(WebStory, slug=slug)
    return render(request, 'web_story_detail.html', {'story': story})


#####################################################--our teem--#########################################################################


def our_teem(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    team_members = TeamMember.objects.all()
    team_banner = MyTeamBanner.objects.last() 

    return render(request, "our_teem.html", {"social":social, 'seo_contents': seo_contents,'Seo':Seo,'team_members': team_members, "team_banner": team_banner})

####################################################--service--##################################################################

def service(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    review = EmployeeReview.objects.all()
    Fq = FaqDetail.objects.all()
    services = Service.objects.all() 
    # Fetch all top featured services ordered by 'order'
    left_services = TopFeaturedService.objects.filter(position='left').order_by('order')
    right_services = TopFeaturedService.objects.filter(position='right').order_by('order')
    
    # Assuming only one main image
    section_image = ServiceSectionImage.objects.first()
    return render(request, "service.html", {"social":social, 'seo_contents': seo_contents,'Seo':Seo,'review':review,"Faq":Fq,"services":services,'left_services': left_services,
        'right_services': right_services,
        'section_image': section_image,})


######################################################################################################################################

def magazine_flipbook(request, slug):
    formatted_slug = slug.replace('-', ' ')
    article = get_object_or_404(Blog, slug__iexact=formatted_slug)

    if not article.magazine_iframe:
        return render(request, "404.html")

    # Recent 10 magazines (excluding current)
    related_magazines = (
        Blog.objects
        .filter(
            magazine_iframe__isnull=False,
            magazine_iframe__gt="",
            magazine_thumbnail__isnull=False
        )
        .exclude(blogid=article.blogid)
        .order_by('-blogid')[:4]
    )


    return render(
        request,
        "magazine_flipbook.html",
        {"article": article, "related_magazines": related_magazines}
    )


####################################################--service-details--###############################################################

def service_detail(request, slug):
    service = get_object_or_404(Service, slug=slug)
    services = Service.objects.all() 
    service_detail = ServiceDetail.objects.filter(service=service).first()
    service_faqs = ServiceFAQ.objects.filter(service=service)
    social = Social_Media_Links.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    context = {
        'service': service,
        'service_detail': service_detail,
        'service_faqs': service_faqs,
        'social': social,
        'seo_contents': seo_contents,
        'Seo': Seo,
        'services':services
    }
    
    return render(request, 'service_detail.html', context)

########################################################-lists-#######################################################################

from django.db.models.functions import ExtractYear
from django.template.loader import render_to_string
from django.http import JsonResponse

def top_lists(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    section_data = TopListsBannerSection.objects.last()

    articles_qs = TopListArticles.objects.filter(status=True).order_by('-date')

    year = request.GET.get("year")
    selected_year = None
    if year and year.isdigit():
        selected_year = int(year)
        articles_qs = articles_qs.filter(date__year=selected_year)

    years = (
        TopListArticles.objects
        .filter(status=True)
        .annotate(y=ExtractYear("date"))
        .values_list("y", flat=True)
        .distinct()
        .order_by("-y")
    )

    recent_articles = TopListArticles.objects.filter(status=True).order_by("-date")[:5]

    # ✅ If AJAX call: return only articles HTML (no full page)
    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        html = render_to_string(
            "toplist_articles.html",
            {"articles": articles_qs},
            request=request
        )
        return JsonResponse({"html": html})

    return render(request, "top_lists.html", {
        "social": social,
        "seo_contents": seo_contents,
        "Seo": Seo,
        "articles": articles_qs,
        "recent_articles": recent_articles,
        "section_data": section_data,
        "years": years,
        "selected_year": selected_year,
    })


########################################################-list-images-##################################################################

def top_lists_images(request, slug):
    article = get_object_or_404(TopListArticles, slug=slug)
    details = TopListArticlesDetails.objects.filter(article=article).order_by('position')  # Fetch related details

    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()

    return render(request, "top_lists_images.html", {
        "social": social, 
        'seo_contents': seo_contents,
        'Seo': Seo,
        'article': article,
        'details': details
    })


######################################################list-details-#####################################################################


def leader_detail(request, article_slug, leader_slug):
    article = get_object_or_404(TopListArticles, slug=article_slug)

    leader = get_object_or_404(TopListArticlesDetails, article=article, slug=leader_slug)

    prev_leader = TopListArticlesDetails.objects.filter(article=article, position__lt=leader.position).order_by('-position').first()
    next_leader = TopListArticlesDetails.objects.filter(article=article, position__gt=leader.position).order_by('position').first()

    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()

    return render(request, "leader_detail.html", {
        "article": article,
        "leader": leader,
        "prev_leader": prev_leader,
        "next_leader": next_leader,
        "social": social,
        "seo_contents": seo_contents,
        "Seo": Seo
    })


####################################################--pricing--plan--##################################################################

def pricing_plan(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    return render(request, "pricing_plan.html", {"social":social, 'seo_contents': seo_contents,'Seo':Seo})

################################################--robots.txt--###############################################################

from django.http import HttpResponse

def robots_txt(request):
    lines = [
        "User-agent: *",
        "Disallow: /admin/",
        "Disallow: /0wzkf6p/",
        "Disallow: /media/interviews/professionals/",
        "Disallow: /media/interviews/business/",
        "Allow: /",
        "Sitemap: https://www.allaroundworlds.com/sitemap.xml",
    ]
    return HttpResponse("\n".join(lines), content_type="text/plain")


################################################- magazine -#################################################################


def magazine_list(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()
    banner = MagazineLists.objects.first() 

    magazine_qs = Blog.objects.filter(
        status=True,
        magazine_iframe__isnull=False,
        magazine_thumbnail__isnull=False,
        magazine_name__isnull=False
    ).order_by('-blogid')

    paginator = Paginator(magazine_qs, 12)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        articles_html = ""

        for article in page_obj:
            article_url = f"/magazine-flipbook/{slugify(article.slug)}"
            articles_html += f'''
            <div class="col-lg-3 col-md-4 col-sm-6 col-12 text-center mb-5">
                <div class="magazine-card">
                    <a href="{article_url}">
                        <img src="{article.magazine_thumbnail.url}" alt="{ article.magazine_name }" class="img-fluid magazine-cover">
                    </a>
                    <h5 class="magazine-title">{ article.title }</h5>
                    <div class="magazine-underline"></div>
                </div>
            </div>
            '''

        return JsonResponse({
            'html': articles_html,
            'has_next': page_obj.has_next()
        })

    return render(request, 'magazine-list.html', {
        'seo_contents': seo_contents,
        'Seo': Seo,
        'social': social,
        'magazine': page_obj,
        'banner': banner,
    })

