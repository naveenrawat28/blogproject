from django.db import models
from ckeditor.fields import RichTextField
from django.utils.text import slugify
from django.utils import timezone


# Create your models here.

class Contact(models.Model):
    id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=20, default=None,
                            blank=True, null=True, db_index=True)
    Email = models.CharField(max_length=30, default=None,
                             blank=True, null=True, db_index=True)
    Phone = models.CharField(max_length=30, default=None,
                             blank=True, null=True, db_index=True)
    Subject = models.CharField(
        max_length=50, default=None, blank=True, null=True, db_index=True)
    Message = models.TextField(blank=True, null=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Name)+"||"+str(self.Email)+"||"
    


class EmployeeReview(models.Model):
    employeereviewid = models.AutoField(primary_key=True)
    employeename = models.TextField(blank=True, null=True)
    employeedesgination = models.TextField(blank=True, null=True)
    employeedepartment = models.TextField(blank=True, null=True)
    employeemessage = models.TextField(blank=True, null=True)
    employeeimage = models.ImageField(upload_to='testimonials/', blank=True, null=True)
    creationdate = models.DateTimeField(auto_now=True, blank=True, null=True)
    stars = models.PositiveIntegerField(default=1, choices=[(i, i) for i in range(1, 6)])

    def __str__(self):
        return "||"+str(self.employeereviewid)+"||"+str(self.employeename)+"||"
    

class TermsofServiceDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=100, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.TextField(
        default=None, blank=True, null=True, db_index=True)
    contentimage = models.ImageField(upload_to='', blank=True, null=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Title)+"||"


class AboutDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=150, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.TextField(default=None, blank=True, null=True, db_index=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+(self.Title)+"||"
    

class Blog_Category(models.Model):
    blog_category_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, unique=True, blank=True, null=True)

    def __str__(self):
        return str(self.name)
    

class Blog(models.Model):
    blogid = models.AutoField(primary_key=True)
    meta_title = models.TextField( max_length=200, unique=True, blank=True, null=True)
    meta_description = models.TextField( max_length=200, unique=True, blank=True, null=True)
    slug = models.CharField( max_length=100, unique=True, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    title = models.CharField(max_length=200, unique=True, blank=True, null=True)
    blog_categories = models.ForeignKey(Blog_Category,on_delete=models.CASCADE)
    short_discription = models.TextField(max_length=200, blank=True, null=True)
    discription = RichTextField(blank=True, null=True)
    image = models.ImageField(upload_to='', blank=True, null=True)
    alt_text= models.CharField(max_length=200, blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    date = models.DateTimeField(blank=True, null=True)   
    likes = models.IntegerField(default=0, blank=True, null=True)
    status = models.BooleanField(default=True)

    magazine_iframe = models.TextField(blank=True, null=True, help_text="Paste embed code (iframe) here.")
    magazine_thumbnail = models.ImageField(upload_to='magazines/thumbnails/', blank=True, null=True)
    magazine_name = models.CharField(max_length=255, blank=True, null=True)

    participant_name = models.CharField(max_length=255, blank=True, null=True)
    participant_linkedin = models.URLField(max_length=500, blank=True, null=True)

    # ✅ NEW FIELD (RichText)
    magazine_about = RichTextField(blank=True, null=True)

    def __str__(self):
        return str(self.title)
    
class Blogdetails(models.Model):
    blogdetailsid = models.AutoField(primary_key=True)
    blogid= models.ForeignKey(Blog, on_delete=models.CASCADE)
    title = models.TextField(blank=True, null=True)
    discription = RichTextField(blank=True, null=True)
    image = models.ImageField(upload_to='', blank=True, null=True)
    alt_text= models.CharField(max_length=200, blank=True, null=True)
   

    def __str__(self):
        return "||"+str(self.blogdetailsid)+"||"+str(self.blogid)+"||"
    

class BlogCategory(models.Model):
    blogcategoryid = models.AutoField(primary_key=True)
    blogcategory = models.TextField()
    blogcategory_count = models.TextField()

    def __str__(self):
        return "||"+str(self.blogcategoryid)+"||"+str(self.blogcategory)+"||"


class BlogComments(models.Model):
    commentid = models.AutoField(primary_key=True)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE, related_name='blogrb')
    Commenttext = models.TextField()
    name = models.CharField(max_length=20)
    totallikes = models.IntegerField(null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True)
    isapproved = models.BooleanField(default=False, blank=True, null=True)

    def __str__(self):
        return f"||{self.commentid}||{self.name}||{self.date}||BlogID: {self.blog.blogid}"



class FaqDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=150, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.CharField(
        max_length=1000, default=None, blank=True, null=True, db_index=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Title)+"||"
    

class Seo_Content(models.Model):
    og_type = models.CharField(max_length=150, blank=True, null=True)
    og_title = models.TextField(blank=True, null=True)
    og_site_name = models.CharField(max_length=150, blank=True, null=True)
    og_description = models.TextField(blank=True, null=True)
    og_url = models.CharField(max_length=200,blank=True, null=True)
    og_locale = models.CharField(max_length=150,blank=True, null=True)
    og_img_url = models.CharField(max_length=200,blank=True, null=True)
    og_img_type = models.CharField(max_length=150,blank=True, null=True)
    og_img_width = models.CharField(max_length=150,blank=True, null=True)
    og_img_height = models.CharField(max_length=150,blank=True, null=True)
    og_img_secure_url = models.CharField(max_length=250,blank=True, null=True)
    og_see_also = models.CharField(max_length=150, blank=True, null=True)
    aticle_author = models.CharField(max_length=150, blank=True, null=True)
    # format_detecation = models.CharField(max_length=150, blank=True, null=True)
    twitter_card = models.CharField(max_length=150, blank=True, null=True)
    twitter_site = models.CharField(max_length=150, blank=True, null=True)
    twitter_creator = models.CharField(max_length=150, blank=True, null=True)
    twitter_title = models.TextField(blank=True, null=True)
    twitter_image_url = models.CharField(max_length=200,blank=True, null=True)
    twitter_image_alt = models.CharField(max_length=150, blank=True, null=True)
    twitter_player = models.CharField(max_length=150, blank=True, null=True)
    twitter_player_width = models.CharField(max_length=150, blank=True, null=True)
    twitter_player_height = models.CharField(max_length=150, blank=True, null=True)
    google_site_verification = models.CharField(max_length=150, blank=True, null=True)
    

    def __str__(self):
        return "||"+str(self.og_title)+"||"+str(self.og_site_name)+"||"


class Home_Page_Detail(models.Model):
    id = models.AutoField(primary_key=True)
    Banner_Title = models.TextField(max_length=200, unique=True)
    Banner_Description = models.TextField(max_length=2000, unique=True)
    Banner_Image = models.ImageField(upload_to='', db_index=True)
    Web_Title = models.CharField(max_length=200, unique=True)
    Web_Description = models.TextField(max_length=2000, unique=True)
    Box_Image = models.ImageField(upload_to='', db_index=True)
    Box_Title1 = models.CharField(max_length=35, unique=True)
    Box_Title2 = models.CharField(max_length=70, unique=True)
    Box_Title3 = models.TextField(max_length=400, unique=True)
    
    def __str__(self):
        return str(self.id) + " || "+(self.Banner_Title)
    
class Social_Media_Links(models.Model):
    Facebook = models.TextField(blank=True, null=True)
    Twitter = models.TextField(blank=True, null=True)
    Instagram = models.TextField(blank=True, null=True)
    Linkdin = models.TextField(blank=True, null=True)
    Youtube = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return str(self.id) + " || "+(self.Facebook)
    

class PageName(models.Model):
    name = models.CharField(max_length=200, unique=True)

    def __str__(self):
        return self.name

class Pagewise_Seo(models.Model):
    page = models.ForeignKey(PageName, on_delete=models.CASCADE)
    meta_title = models.CharField(max_length=200, blank=True, null=True)
    meta_description = models.TextField(blank=True, null=True)
    meta_keywords = models.CharField(max_length=300, blank=True, null=True)

    def __str__(self):
        return str(self.page)

class TelegramChatid(models.Model):
    chat_id = models.CharField(max_length=100, unique=True,)

    def __str__(self):
        return str(self.chat_id)


# Model for Business Owners/Entrepreneurs
class BusinessOwner(models.Model):
    name = models.CharField(max_length=255)
    website_url = models.URLField()
    facebook_url = models.URLField(blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    instagram_url = models.URLField(blank=True, null=True)
    twitter_url = models.URLField(blank=True, null=True)
    about_yourself = models.TextField()
    business_overview = models.TextField()
    key_achievement = models.TextField()
    growth_plans = models.TextField()
    competitive_advantage = models.TextField()
    advice_entrepreneurs = models.TextField()
    image1 = models.ImageField(upload_to='interviews/business/', blank=True, null=True)
    image2 = models.ImageField(upload_to='interviews/business/', blank=True, null=True)
    image3 = models.ImageField(upload_to='interviews/business/', blank=True, null=True)

    def __str__(self):
        return self.name

# Model for Industry Leaders/Professionals
class Professional(models.Model):
    name = models.CharField(max_length=255)
    website_url = models.URLField()
    facebook_url = models.URLField(blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    instagram_url = models.URLField(blank=True, null=True)
    twitter_url = models.URLField(blank=True, null=True)
    about_yourself = models.TextField()
    current_role = models.TextField()
    professional_accomplishment = models.TextField()
    career_challenge = models.TextField()
    stay_ahead = models.TextField()
    advice_young_professional = models.TextField()
    image1 = models.ImageField(upload_to='interviews/professionals/', blank=True, null=True)
    image2 = models.ImageField(upload_to='interviews/professionals/', blank=True, null=True)
    image3 = models.ImageField(upload_to='interviews/professionals/', blank=True, null=True)

    def __str__(self):
        return self.name


class WebStory(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    thumbnail = models.ImageField(upload_to='thumbnails/', blank=True, null=True)
    slug = models.SlugField(blank=True, null=True, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) 
            slug_candidate = base_slug
            num = 1

            while WebStory.objects.filter(slug=slug_candidate).exists():
                slug_candidate = f"{base_slug}-{num}"
                num += 1

            self.slug = slug_candidate 

        super(WebStory, self).save(*args, **kwargs)

class Slide(models.Model):
    web_story = models.ForeignKey(WebStory, related_name='slides', on_delete=models.CASCADE)
    title = models.CharField(max_length=200, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='slides/', blank=True, null=True)
    video = models.FileField(upload_to='slides/', blank=True, null=True)

    def __str__(self):
        return f"Slide for {self.web_story.title}"
    

class TeamMember(models.Model):
    name = models.CharField(max_length=100)
    position = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='',)
    linkedin = models.CharField(max_length=1000)
    facebook = models.CharField(max_length=1000)
    instagram = models.CharField(max_length=1000)

    def __str__(self):
        return self.name
    
#############################################################################-OurClient-#####################################################

class OurClient(models.Model):
    name = models.CharField(max_length=255)
    url = models.URLField()
    logo = models.ImageField(upload_to='client_logos/')

    def __str__(self):
        return self.name

#############################################################################-Service-#####################################################

class Service(models.Model):
    service_name = models.CharField(max_length=255)
    short_description = models.TextField()
    icon = models.ImageField(upload_to='services/', blank=True, null=True) 
    slug = models.SlugField(unique=True)

    def __str__(self):
        return self.service_name

#############################################################################-ServiceDetail-#####################################################

class ServiceDetail(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="details")
    meta_title = models.CharField(max_length=60)
    meta_description = models.TextField()
    meta_keywords = models.TextField()
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='service_details/', blank=True, null=True)
    tagline = models.CharField(max_length=1000)
    service_details = RichTextField(blank=True, null=True)

    def __str__(self):
        return f"{self.title} - Details for {self.service.service_name}"

#############################################################################-ServiceFAQ-#####################################################
    
class ServiceFAQ(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="faqs")
    question = models.CharField(max_length=255)
    answer = models.TextField()

    def __str__(self):
        return f"FAQ for {self.service.service_name}: {self.question}"


#############################################################################-TopListArticles-#####################################################

class TopListArticles(models.Model):
    article_id = models.AutoField(primary_key=True)
    meta_title = models.TextField(max_length=200, unique=True, blank=True, null=True)
    meta_description = models.TextField(max_length=200, unique=True, blank=True, null=True)
    slug = models.CharField(max_length=100, unique=True, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    description = RichTextField(blank=True, null=True)
    image = models.ImageField(upload_to='top_list_articles/', blank=True, null=True)
    alt_text = models.CharField(max_length=200, blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    date = models.DateTimeField(default=timezone.now)
    status = models.BooleanField(default=True)
    
    def __str__(self):
        return f"Article {self.article_id}"

###############################################################################-TopListArticlesDetails-##############################################

class TopListArticlesDetails(models.Model):
    article = models.ForeignKey('TopListArticles', on_delete=models.CASCADE)
    meta_title = models.TextField(max_length=200, unique=True, blank=True, null=True)
    meta_description = models.TextField(max_length=200, unique=True, blank=True, null=True)
    meta_keyword = models.TextField(blank=True, null=True)
    leader_name = models.CharField(max_length=255, blank=True, null=True)
    leader_designation = models.CharField(max_length=255, blank=True, null=True)
    linkedin_url = models.URLField(max_length=255, blank=True, null=True)
    instagram_url = models.URLField(max_length=255, blank=True, null=True)
    facebook_url = models.URLField(max_length=255, blank=True, null=True)
    image = models.ImageField(upload_to='top_list_articles/', blank=True, null=True)
    slug = models.CharField(max_length=100, blank=True, null=True)
    key_details = RichTextField(blank=True, null=True)
    description = RichTextField(blank=True, null=True)
    date = models.DateTimeField(default=timezone.now)
    position = models.PositiveIntegerField(blank=True, null=True) 
    
    def save(self, *args, **kwargs):
        if not self.position:
            last_position = TopListArticlesDetails.objects.filter(article=self.article).aggregate(models.Max('position'))['position__max']
            self.position = (last_position or 0) + 1  
        super().save(*args, **kwargs)

    def __str__(self):
        return self.leader_name if self.leader_name else f"Details for {self.article.article_id}"

###################################################################################################################################################

class TopListsBannerSection(models.Model):
    title = models.CharField(max_length=255, help_text="Title of the section")
    description = models.TextField(help_text="Description of the section")
    image = models.ImageField(upload_to="toplists_banners/", blank=True, null=True)

    def __str__(self):
        return self.title

####################################################################################################################################################

class MyTeamBanner(models.Model):
    title = models.CharField(max_length=255, help_text="Title of the section")
    description = models.TextField(help_text="Description of the section")
    image = models.ImageField(upload_to="team_banners/", blank=True, null=True)

    def __str__(self):
        return self.title

####################################################################################################################################################


class MagazineLists(models.Model):
    title = models.CharField(max_length=255, help_text="Enter the banner heading/title")
    description = models.TextField(help_text="Enter the banner description. You can use basic HTML.")
    image = models.ImageField(upload_to='banners/', null=True, blank=True, help_text="Upload an optional image for the banner")

    def __str__(self):
        return self.title

#####################################################################################################################################################

from urllib.parse import urlparse

class URLRedirect(models.Model):
    old_path = models.CharField(
        max_length=255, 
        unique=True, 
        help_text="Enter the old path like /old-page/. If full URL is entered, it will auto-convert."
    )
    new_url = models.URLField(help_text="Enter the full new URL to redirect to.")

    def save(self, *args, **kwargs):
        parsed = urlparse(self.old_path)
        self.old_path = parsed.path
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.old_path} → {self.new_url}"

from django.db import models

class ServiceSectionImage(models.Model):
    image = models.ImageField(
        upload_to='service_section_images/',
        verbose_name="Section Image",
        help_text="Upload an image for the service section"
    )

    def __str__(self):
        return self.image.name

    class Meta:
        verbose_name = "Service Section Image"
        verbose_name_plural = "Service Section Images"


class TopFeaturedService(models.Model):
    POSITION_CHOICES = (
        ('left', 'Left'),
        ('right', 'Right'),
    )

    title = models.CharField(
        max_length=200,
        verbose_name="Service Title",
        help_text="Title of the featured service"
    )
    description = models.TextField(
        verbose_name="Description",
        help_text="Detailed description of the service",
        blank=True
    )
    icon = models.CharField(
        max_length=100,
        verbose_name="Icon Class",
        help_text="FontAwesome icon class. Example: fas fa-newspaper",
        blank=True
    )
    link = models.URLField(
        verbose_name="Service Link",
        help_text="URL to link the service",
        blank=True
    )
    position = models.CharField(
        max_length=10,
        choices=POSITION_CHOICES,
        verbose_name="Position",
        help_text="Position of the service on the page"
    )
    order = models.PositiveIntegerField(
        verbose_name="Display Order",
        help_text="Order in which this service appears"
    )

    def __str__(self):
        return f"{self.title} ({self.position.capitalize()})"

    class Meta:
        ordering = ['order']
        verbose_name = "Top Featured Service"
        verbose_name_plural = "Top Featured Services"