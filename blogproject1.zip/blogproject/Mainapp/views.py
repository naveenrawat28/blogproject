from django.shortcuts import render

from Mainapp.models import *
import sys,json
from django.conf import settings
import urllib.request
from django.shortcuts import redirect
from django.contrib import messages
import itertools
from collections import Counter
from django.views.generic.base import TemplateView
import os
import json
import hashlib
import base64
from django.http import HttpResponse
from django.core.mail import send_mail
import urllib.parse
import urllib.request
import asyncio
from telegram import Bot




# Create your views here.


def search_results(request):
    query = request.GET.get('query', '')
    if query:
        blogs = Blog.objects.filter(title__icontains=query)
    else:
        blogs = Blog.objects.none()

    return render(request, 'search_result.html', {'blogs': blogs})

######################################################################

def Blog_Home(request):
    review = EmployeeReview.objects.all()
    bcate = BlogCategory.objects.all()
    blog = Blog.objects.all().order_by('-date')[:48]
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    social = Social_Media_Links.objects.all()
    homedetail = Home_Page_Detail.objects.all()
    return render(request, "index.html",{'review': review,'cate':bcate, "blogdeatils": blog, "social":social, "homedetail":homedetail,'seo_contents': seo_contents, 'Seo':Seo})

############################################################################################################################################# 

def blogcatecount():
    cate = Blog.objects.values_list('blog_categories__name', flat=True)
    print('Categories', cate, type(cate))
    counts = Counter(cate)
    count_dict = dict(counts)
    for i in count_dict:
        print(i, count_dict[i])
        bcate = BlogCategory.objects.filter(blogcategory__icontains=i)
        if bcate.exists():
            bc = bcate[0]
            bc.blogcategory_count = count_dict[i]
            bc.save(update_fields=['blogcategory_count'])
            print("Function")
        else:
            bcate = BlogCategory(
                blogcategory=i, blogcategory_count=count_dict[i])
            bcate.save()
            print("execute")

#############################################################################################################################################


def Blogs(request, var=None):
    bcate = BlogCategory.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    blogcatecount()
    blog = Blog.objects.all().order_by('-date')
    social = Social_Media_Links.objects.all()
    base_url = "{0}://{1}{2}".format(request.scheme,request.get_host(), request.path)
    print("Url", base_url)
    return render(request, "blog.html", {"blogdeatils": blog,'cate':bcate, 'link': base_url,"social":social, 'seo_contents': seo_contents, 'Seo':Seo})

#############################################################################################################################################


def Blogscate(request, cate, var=None):
    bcate = BlogCategory.objects.all()
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    blogcatecount()
    cate = cate.replace('-', ' ')
    base_url = "{0}://{1}{2}".format(request.scheme,request.get_host(), request.path)
    print("Url", base_url)
    blog = Blog.objects.filter(blog_categories__name__icontains=cate).order_by('-date')
    social = Social_Media_Links.objects.all()
    return render(request, "blogs.html", { "blogdeatils": blog,'cate':bcate,  'link': base_url,"social":social, 'seo_contents': seo_contents, 'Seo':Seo})


#################################################################################telegram#######################

async def send_telegram_messages(token, chat_ids, name, message):
    bot = Bot(token=token)
    for chat_id in chat_ids:
        try:
            telegram_message = f"New comment on the blog:\n\nName: {name}\nMessage: {message}"
            await bot.send_message(chat_id=chat_id, text=telegram_message)
            print(f"Success sending Telegram message to chat_id {chat_id}")
        except Exception as e:
            print(f"Error sending Telegram message to chat_id {chat_id}: {e}")



async def send_telegram_messages_contuctus(token, chat_ids, name, email, phone, subject, message):
    bot = Bot(token=token)
    telegram_message = (f"New contact request:\n\n" f"Name: {name}\n"f"Email: {email}\n"f"Phone: {phone}\n"f"Subject: {subject}\n"f"Message: {message}")

    for chat_id in chat_ids:
        try:
            await bot.send_message(chat_id=chat_id, text=telegram_message)
            print(f"Success sending Telegram message to chat_id {chat_id}")
        except Exception as e:
            print(f"Error sending Telegram message to chat_id {chat_id}: {e}")


################################################################################end #################################        

def Blog_Deatils(request, name):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    name = name.replace('-', ' ')
    base_url = "{0}://{1}{2}".format(request.scheme, request.get_host(), request.path)
    bldet = Blog.objects.filter(slug__icontains=name)[0]
    bldet1 = bldet.slug
    cate = Blog.objects.get(slug=bldet1).blog_categories
    blog = Blog.objects.filter(blog_categories=cate).order_by('-date')
    social = Social_Media_Links.objects.all()
    bcate = BlogCategory.objects.all()
    blog1 = blog.order_by('-date').values()[0:5]
    bldet = Blog.objects.filter(slug__icontains=name)[0]
    blogdet = Blogdetails.objects.filter(blogid=bldet.blogid)
    bl = BlogComments.objects.filter(blog=bldet, isapproved=True)
    num = len(bl)

    if request.method == 'POST':
        nam = request.POST.get("Name")
        mess = request.POST.get("Message")
        if nam is not None and mess is not None:
            bcom = BlogComments(blog=bldet, name=nam, Commenttext=mess)
            bcom.save()
            email_subject = "New Comment Submitted"
            email_message = f"Name: {nam}\nMessage: {mess}"
            email_from = settings.EMAIL_HOST_USER
            recipient_list = ['sales@allaroundworlds.com'] 
            send_mail(email_subject, email_message, email_from, recipient_list)
            messages.warning(request, 'Your comment is successfully submitted and shows after approval.')

            chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]
            asyncio.run(send_telegram_messages('6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4', chat_ids, nam, mess))

        return redirect(request.META['HTTP_REFERER'])

    return render(request, "blog-details.html", { 'det': bldet, "blogdeatils": blog, 'comm': bl, 'rc': blog1, 'num': num, 'cate': bcate, 'link': base_url,'blogdet':blogdet,"social":social, 'seo_contents': seo_contents, 'Seo':Seo})

##############################################################################################################################################

def likes(request):
    if request.method == 'POST':
        post_id = request.POST.get('task')
        
        try:
            blog_post = Blog.objects.get(blogid=int(post_id))
            
            # Ensure likes is an integer
            if blog_post.likes is None:
                blog_post.likes = 0
            
            blog_post.likes += 1
            blog_post.save()
            return HttpResponse(status=200)

        except Blog.DoesNotExist:
            return HttpResponse(status=404)
        except ValueError:
            return HttpResponse(status=400)
        except Exception as e:
            print("Error:", str(e))
            return HttpResponse(status=500)

######################################################################################################################################
        
def Contactus(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first()
    social = Social_Media_Links.objects.all()

    if request.method == "POST":
        recaptcha_response = request.POST.get('g-recaptcha-response')
        url = 'https://www.google.com/recaptcha/api/siteverify'
        values = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        data = urllib.parse.urlencode(values).encode()
        req = urllib.request.Request(url, data=data)
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode())

        if result['success']:
            Name = request.POST.get("Name")
            Email_id = request.POST.get("Email")
            Phone = request.POST.get("Phone")
            Subject = request.POST.get("Subject")
            Message = request.POST.get('Message')
            ct = Contact(Name=Name, Email=Email_id, Phone=Phone, Message=Message, Subject=Subject)
            ct.save()
            email_subject = f"New Contact from {Name}"
            email_message = f"Name: {Name}\nEmail: {Email_id}\nPhone: {Phone}\nSubject: {Subject}\nMessage: {Message}"
            email_from = settings.EMAIL_HOST_USER
            recipient_list = ['sales@allaroundworlds.com']
            send_mail(email_subject, email_message, email_from, recipient_list)
            messages.success(request, 'Your form has been submitted successfully.')

            chat_ids = [chat.chat_id for chat in TelegramChatid.objects.all()]

            # Send message via Telegram to all chat IDs
            asyncio.run(send_telegram_messages_contuctus('6735056870:AAESpo3G-cWc5HS7SRw84eyZuaQKr_2HtV4', chat_ids, Name, Email_id, Phone, Subject, Message))

    return render(request, "contactus.html", {"social": social, 'seo_contents': seo_contents, 'Seo': Seo})

#############################################################################################################################################

def Terms_Of_Service(request, var=None):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    ter = TermsofServiceDetail.objects.all().order_by('id')
    social = Social_Media_Links.objects.all()
    # ban = PageBanner.objects.all()
    ter = list(ter)
    num = 0
    number = len(ter)
    if number % 2 == 0:
        num = int(number/2)
    else:
        num = int(number/2)
        num = num+1
    list1 = ter[:num]
    list2 = ter[num:]
    comb = list(itertools.zip_longest(list1, list2, fillvalue=None))
    return render(request, "terms-of-service.html", {'ter': comb, "social":social, 'seo_contents': seo_contents, 'Seo':Seo})

#############################################################################################################################################

def About(request, var=None):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    At = AboutDetail.objects.all().order_by('id')
    social = Social_Media_Links.objects.all()
    return render(request, "aboutus.html", {"About": At , "social":social, 'seo_contents': seo_contents, 'Seo':Seo})

#############################################################################################################################################

def Faq(request):
    seo_contents = Pagewise_Seo.objects.all()
    Seo = Seo_Content.objects.first() 
    Fq = FaqDetail.objects.all()
    social = Social_Media_Links.objects.all()
    return render(request, "faq.html", {'Faq': Fq, "social":social, 'seo_contents': seo_contents,'Seo':Seo})

#############################################################################################################################################

def site(request):
    return HttpResponse(open('Mainapp/templates/sitemap.xml').read(), content_type='text/xml')

#############################################################################################################################################

def read_file(request):
    f = open('Mainapp/templates/robots.txt', 'r')
    file_content = f.read()
    f.close()
    return HttpResponse(file_content, content_type="text/plain")

#############################################################################################################################################

class RobotsView(TemplateView):
    template_name = "robots.txt"
    content_type = "text/plain"

#############################################################################################################################################

def custom_404(request, exception):
    return redirect('/') 

#############################################################################################################################################

def acme_challenge(request, token):
    your_public_key_n_value = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAk8CXbWVkMbt8q/NHl7QkdhjAg03rrCd276BVtpWEY1JTZUyubC/QSZc0KM1phEhdd+w+oj4ptPYqOsCdCvU4YATU8iU1RsGHuw8EkpHt3g7qx3/8t4LFtFYNe0xam/7tRprT00BcrcuETlV0WNb78kGmSrrDhDBQ9kPfgsKg1YJU3N0KJAtaGmeUhEb05hjOoDKJg1fO9WbaJhhj60EbEgWic6y8OOa047y4lJyJZlsIGkn+62qg0TvXNHIdwM2Fej29Xcy+DWzLDVH1Bp+mSSeMJsG1kYiMjop9H5Qc28vY95slmlfFHZ+PU68KWF8MwAcbaG5DpDOz3Od5qECivQIDAQAB "
    # Use the actual token and JWK values
    jwk = {"e": "AQAB", "kty": "RSA", "n": your_public_key_n_value}
    serialized_jwk = json.dumps(jwk, sort_keys=True, separators=(',', ':'))
    sha256_digest = hashlib.sha256(serialized_jwk.encode('utf-8')).digest()
    thumbprint = base64.urlsafe_b64encode(sha256_digest).decode('utf-8').rstrip("=")
    key_authorization = token + '.' + thumbprint

    # File path for the token file
    file_path = os.path.join('Mainapp/static/.well-known/acme-challenge', token)

    # Write key_authorization to the file
    with open(file_path, 'w') as file:
        file.write(key_authorization)

    # Read the file and return its content in the response
    with open(file_path, 'r') as file:
        response_content = file.read()

    return HttpResponse(response_content, content_type='text/plain')

#############################################################################################################################################


# def search_results(request):
#     bcate = BlogCategory.objects.all()
#     seo_contents = Pagewise_Seo.objects.all()
#     Seo = Seo_Content.objects.first()
#     social = Social_Media_Links.objects.all()
#     query = request.GET.get('query', '')

#     print("Search query:", query)

#     # if query:
#     #     try:
#     #         blog = Blog.objects.filter(title__icontains=query)
#     #         print("Number of blogs found:", blog.count())
#     #     except IndexError as e:
#     #         print("IndexError occurred:", e)
#     #         blog = Blog.objects.none()
#     # else:
#     #     blog = Blog.objects.none()

#     return render(request, "blogs.html")

