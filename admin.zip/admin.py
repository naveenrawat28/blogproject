from django.contrib import admin
from django import forms
from ckeditor.widgets import CKEditorWidget
from .models import *

# ---------------- INLINE FORMS ---------------- #

class BlogdetailsInlineForm(forms.ModelForm):
    discription = forms.CharField(widget=CKEditorWidget(), required=False)

    class Meta:
        model = Blogdetails
        fields = '__all__'

class BlogdetailsInline(admin.StackedInline):
    model = Blogdetails
    form = BlogdetailsInlineForm
    extra = 1
    fieldsets = (
        (None, {
            'fields': ('title', 'discription', 'image', 'alt_text')
        }),
    )

class BlogCommentsInline(admin.StackedInline):
    model = BlogComments
    extra = 1

class TopListArticlesDetailsInline(admin.StackedInline):
    model = TopListArticlesDetails
    extra = 1

class ServiceDetailInline(admin.StackedInline):
    model = ServiceDetail
    extra = 1

class ServiceFAQInline(admin.StackedInline):
    model = ServiceFAQ
    extra = 1

class SlideInline(admin.StackedInline):
    model = Slide
    extra = 1

# ---------------- BLOG & RELATED MODELS ---------------- #

@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    inlines = [BlogdetailsInline, BlogCommentsInline]
    list_display = ('title', 'date', 'status')
    search_fields = ('title', 'meta_title')

@admin.register(Blogdetails)
class BlogdetailsAdmin(admin.ModelAdmin):
    list_display = ('blogid', 'title', 'image')
    search_fields = ('title', 'blogid__title')
    list_filter = ('blogid',)

# ---------------- SERVICE MODELS ---------------- #

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    inlines = [ServiceDetailInline, ServiceFAQInline]
    list_display = ('service_name', 'slug')
    search_fields = ('service_name', 'slug')

# ---------------- TOP LIST ARTICLES ---------------- #

@admin.register(TopListArticles)
class TopListArticlesAdmin(admin.ModelAdmin):
    inlines = [TopListArticlesDetailsInline]
    list_display = ('title', 'date', 'status')
    search_fields = ('title', 'meta_title')
    list_filter = ('status', 'date')

# ---------------- WEB STORIES ---------------- #

@admin.register(WebStory)
class WebStoryAdmin(admin.ModelAdmin):
    inlines = [SlideInline]
    list_display = ('title', 'created_at')
    search_fields = ('title',)

# ---------------- EMPLOYEE REVIEWS ---------------- #

@admin.register(EmployeeReview)
class EmployeeReviewAdmin(admin.ModelAdmin):
    list_display = ('employeename', 'employeedesgination', 'stars', 'has_image', 'creationdate')
    list_filter = ('stars',)
    search_fields = ('employeename', 'employeedesgination', 'employeemessage')
    ordering = ('-creationdate',)

    def has_image(self, obj):
        return bool(obj.employeeimage)
    has_image.boolean = True
    has_image.short_description = 'Image'

# ---------------- NEW MODELS ---------------- #

@admin.register(ServiceSectionImage)
class ServiceSectionImageAdmin(admin.ModelAdmin):
    list_display = ('image', 'image_preview')
    search_fields = ('image',)
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:
            return f'<img src="{obj.image.url}" width="100" height="50" />'
        return "-"
    image_preview.allow_tags = True
    image_preview.short_description = "Preview"

@admin.register(TopFeaturedService)
class TopFeaturedServiceAdmin(admin.ModelAdmin):
    list_display = ('title', 'position', 'order')
    list_filter = ('position',)
    search_fields = ('title', 'description', 'icon')
    ordering = ('order',)


# ---------------- SIMPLE ADMIN REGISTRATION ---------------- #

models_to_register = [
    Contact, TermsofServiceDetail, AboutDetail, Blog_Category,
    BlogCategory, BlogComments, FaqDetail, Seo_Content, Home_Page_Detail,
    Social_Media_Links, PageName, Pagewise_Seo, TelegramChatid, BusinessOwner,
    Professional, TeamMember, OurClient, URLRedirect, TopListsBannerSection,
    MyTeamBanner, MagazineLists
]

for model in models_to_register:
    admin.site.register(model)