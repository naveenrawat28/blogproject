from django.contrib import admin
from .models import *


@admin.register(TopListsBannerSection)
class TopListsBannerSectionAdmin(admin.ModelAdmin):
    list_display = ("title", "image")

#######################################################################################################

@admin.register(MyTeamBanner)
class MyTeamBannerAdmin(admin.ModelAdmin):
    list_display = ("title", "image")

#######################################################################################################

@admin.register(TopListArticles)
class TopListArticlesAdmin(admin.ModelAdmin):
    list_display = ('article_id', 'name', 'title', 'status', 'date')
    search_fields = ('name', 'title', 'meta_title', 'slug')
    list_filter = ('status', 'date')
    prepopulated_fields = {'slug': ('title',)}

#######################################################################################################

@admin.register(TopListArticlesDetails)
class TopListArticlesDetailsAdmin(admin.ModelAdmin):
    list_display = ('article', 'leader_name', 'leader_designation', 'position')
    search_fields = ('leader_name', 'leader_designation', 'meta_title', 'slug')
    list_filter = ('article',)
    ordering = ('position',) 

#######################################################################################################

admin.site.register((EmployeeReview, Contact, TermsofServiceDetail, AboutDetail, Blog, BlogComments, Blogdetails, Blog_Category, BlogCategory, Social_Media_Links, Home_Page_Detail, FaqDetail, Pagewise_Seo, PageName, Seo_Content,TelegramChatid,WebStory,Slide,TeamMember,OurClient,BusinessOwner,Professional,Service,ServiceDetail,ServiceFAQ))
