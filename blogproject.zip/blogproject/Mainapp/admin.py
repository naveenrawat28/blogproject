from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register((EmployeeReview, Contact, TermsofServiceDetail, AboutDetail, Blog, BlogComments, Blogdetails, Blog_Category, BlogCategory, Social_Media_Links, Home_Page_Detail, FaqDetail, Pagewise_Seo, PageName, Seo_Content,TelegramChatid,WebStory,Slide,TeamMember,OurClient,BusinessOwner,Professional,Service,ServiceDetail,ServiceFAQ))
