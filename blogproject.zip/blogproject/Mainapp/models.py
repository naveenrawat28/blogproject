from django.db import models

# Create your models here.

class Contact(models.Model):
    id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=20, default=None,
                            blank=True, null=True, db_index=True)
    Email = models.CharField(max_length=30, default=None,
                             blank=True, null=True, db_index=True)
    Subject = models.CharField(
        max_length=50, default=None, blank=True, null=True, db_index=True)
    Message = models.TextField(blank=True, null=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Name)+"||"+str(self.Email)+"||"
    


class EmployeeReview(models.Model):
    employeereviewid = models.AutoField(primary_key=True)
    employeename = models.TextField(blank=True, null=True)
    employeedesgination = models.TextField(blank=True, null=True)
    employeedepartment = models.TextField(blank=True, null=True)
    employeemessage = models.TextField(blank=True, null=True)
    employeeimage = models.ImageField(upload_to='',)
    creationdate = models.DateTimeField(auto_now=True, blank=True, null=True)

    def __str__(self):
        return "||"+str(self.employeereviewid)+"||"+str(self.employeename)+"||"
    

class TermsofServiceDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=100, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.TextField(
        default=None, blank=True, null=True, db_index=True)
    contentimage = models.ImageField(upload_to='', blank=True, null=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Title)+"||"


class AboutDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=150, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.TextField(default=None, blank=True, null=True, db_index=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+(self.Title)+"||"
    

class Blog_Category(models.Model):
    blog_category_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, unique=True, blank=True, null=True)

    def __str__(self):
        return str(self.name)
    

class Blog(models.Model):
    blogid = models.AutoField(primary_key=True)
    meta_title = models.TextField( max_length=100, unique=True, blank=True, null=True)
    meta_description = models.TextField( max_length=200, unique=True, blank=True, null=True)
    slug = models.CharField( max_length=100, unique=True, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    title = models.CharField(max_length=100, unique=True, blank=True, null=True)
    blog_categories = models.ForeignKey(Blog_Category,on_delete=models.CASCADE)
    short_discription = models.TextField(max_length=200, blank=True, null=True)
    discription = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='', blank=True, null=True)
    alt_text= models.CharField(max_length=200, blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    date = models.DateTimeField(auto_now_add=True)
    likes = models.IntegerField(default=0, blank=True, null=True)

    def __str__(self):
        return str(self.title)
    
class Blogdetails(models.Model):
    blogdetailsid = models.AutoField(primary_key=True)
    blogid= models.ForeignKey(Blog, on_delete=models.CASCADE)
    title = models.TextField(blank=True, null=True)
    discription = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='', blank=True, null=True)
    alt_text= models.CharField(max_length=200, blank=True, null=True)
   

    def __str__(self):
        return "||"+str(self.blogdetailsid)+"||"+str(self.blogid)+"||"
    


class BlogCategory(models.Model):
    blogcategoryid = models.AutoField(primary_key=True)
    blogcategory = models.TextField()
    blogcategory_count = models.TextField()

    def __str__(self):
        return "||"+str(self.blogcategoryid)+"||"+str(self.blogcategory)+"||"


class BlogComments(models.Model):
    commentid = models.AutoField(primary_key=True)
    blog = models.ForeignKey(
        Blog, models.DO_NOTHING, related_name='blogrb')
    Commenttext = models.TextField()
    name = models.CharField(max_length=20)
    totallikes = models.IntegerField(null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True)
    isapproved = models.BooleanField(default=False, blank=True, null=True)

    def __str__(self):
        return "||"+str(self.commentid)+"||"+str(self.name)+"||"+str(self.date)+"||"


class FaqDetail(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=150, default=None,
                             blank=True, null=True, db_index=True)
    Description = models.CharField(
        max_length=1000, default=None, blank=True, null=True, db_index=True)

    def __str__(self):
        return "||"+str(self.id)+"||"+str(self.Title)+"||"
    

class Seo_Content(models.Model):
    og_type = models.CharField(max_length=150, blank=True, null=True)
    og_title = models.TextField(blank=True, null=True)
    og_site_name = models.CharField(max_length=150, blank=True, null=True)
    og_description = models.TextField(blank=True, null=True)
    og_url = models.CharField(max_length=200,blank=True, null=True)
    og_locale = models.CharField(max_length=150,blank=True, null=True)
    og_img_url = models.CharField(max_length=200,blank=True, null=True)
    og_img_type = models.CharField(max_length=150,blank=True, null=True)
    og_img_width = models.CharField(max_length=150,blank=True, null=True)
    og_img_height = models.CharField(max_length=150,blank=True, null=True)
    og_img_secure_url = models.CharField(max_length=250,blank=True, null=True)
    og_see_also = models.CharField(max_length=150, blank=True, null=True)
    aticle_author = models.CharField(max_length=150, blank=True, null=True)
    # format_detecation = models.CharField(max_length=150, blank=True, null=True)
    twitter_card = models.CharField(max_length=150, blank=True, null=True)
    twitter_site = models.CharField(max_length=150, blank=True, null=True)
    twitter_creator = models.CharField(max_length=150, blank=True, null=True)
    twitter_title = models.TextField(blank=True, null=True)
    twitter_image_url = models.CharField(max_length=200,blank=True, null=True)
    twitter_image_alt = models.CharField(max_length=150, blank=True, null=True)
    twitter_player = models.CharField(max_length=150, blank=True, null=True)
    twitter_player_width = models.CharField(max_length=150, blank=True, null=True)
    twitter_player_height = models.CharField(max_length=150, blank=True, null=True)
    google_site_verification = models.CharField(max_length=150, blank=True, null=True)
    

    def __str__(self):
        return "||"+str(self.og_title)+"||"+str(self.og_site_name)+"||"


class Home_Page_Detail(models.Model):
    id = models.AutoField(primary_key=True)
    Banner_Title = models.TextField(max_length=200, unique=True)
    Banner_Description = models.TextField(max_length=2000, unique=True)
    Banner_Image = models.ImageField(upload_to='', db_index=True)
    Web_Title = models.CharField(max_length=70, unique=True)
    Web_Description = models.TextField(max_length=2000, unique=True)
    Box_Image = models.ImageField(upload_to='', db_index=True)
    Box_Title1 = models.CharField(max_length=35, unique=True)
    Box_Title2 = models.CharField(max_length=70, unique=True)
    Box_Title3 = models.TextField(max_length=400, unique=True)
    
    def __str__(self):
        return str(self.id) + " || "+(self.Banner_Title)
    
class Social_Media_Links(models.Model):
    Facebook = models.TextField(blank=True, null=True)
    Twitter = models.TextField(blank=True, null=True)
    Instagram = models.TextField(blank=True, null=True)
    Linkdin = models.TextField(blank=True, null=True)
    Youtube = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return str(self.id) + " || "+(self.Facebook)
    

class PageName(models.Model):
    name = models.CharField(max_length=200, unique=True)

    def __str__(self):
        return self.name

class Pagewise_Seo(models.Model):
    page = models.ForeignKey(PageName, on_delete=models.CASCADE)
    meta_title = models.CharField(max_length=200, blank=True, null=True)
    meta_description = models.TextField(blank=True, null=True)
    meta_keywords = models.CharField(max_length=300, blank=True, null=True)

    def __str__(self):
        return str(self.page)
